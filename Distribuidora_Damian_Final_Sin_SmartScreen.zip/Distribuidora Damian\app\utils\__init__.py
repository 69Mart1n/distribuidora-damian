"""Utilidades compartidas."""
