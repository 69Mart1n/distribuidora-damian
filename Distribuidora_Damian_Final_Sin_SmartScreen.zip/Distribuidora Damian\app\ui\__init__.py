"""Interfaz grafica."""
